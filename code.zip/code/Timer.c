#include "Timer.h"
#include "Speed_PID.h"

void Timer2_Init(void)
{
    pit_ms_init(PIT_CH0, 100);
    interrupt_enable(PIT_IRQn);
    interrupt_set_priority(PIT_IRQn, 5);
}

void Timer2_IRQHandler(void)
{
    gpio_toggle_level(B9);

    Speed_PID_Init(); // 调试
    // 100ms周期中断处理函数
    // 在这里添加你的周期性任务代码
    // 例如: PID控制、数据采样、LED闪烁等
}

#ifndef __MOTOR_H__
#define __MOTOR_H__

#include "zf_common_headfile.h"

// Motor Pin 控制电机正反转引脚
#define MOTOR_L1_IN1_PIN  B10
#define MOTOR_L1_IN2_PIN  B11

#define MOTOR_L2_IN1_PIN  B12
#define MOTOR_L2_IN2_PIN  B13

#define MOTOR_R1_IN1_PIN  B14
#define MOTOR_R1_IN2_PIN  B15

#define MOTOR_R2_IN1_PIN  B16
#define MOTOR_R2_IN2_PIN  B17

void Motor_Init(void);
void Motor_Left_Forward(void);
void Motor_Left_Reverse(void);
void Motor_Right_Forward(void);
void Motor_Right_Reverse(void);
void Motor_Left_Stop(void);
void Motor_Right_Stop(void);
void Motor_Forward(void);
void Motor_Backward(void);

#endif // __MOTOR_H__

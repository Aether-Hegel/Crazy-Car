#ifndef SPEED_PID_H
#define SPEED_PID_H

#include "zf_common_headfile.h"
#include "UART.h"

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float target_speed;//目标速度
    float Actual_speed;//实际速度
    float error_last;//上一次误差
    float error_current;//当前误差
    float error_sum;//误差累计和
    float output;//输出值
    float Pwm_Max_Out;//限幅输出值

}Speed_PID;

void Set_Speed_PID(Speed_PID *pid, float Kp, float Ki, float Kd, float target, float PWM_MAX_OUt);
void Speed_PID_Init();
void Speed_PID_Calculate(Speed_PID *pid, float current_speed);
void Speed_Car();

#endif // SPEED_PID_H

#include "Motor.h"

void Motor_Init(void)
{
    // GPIO口初始化 推挽输出 初始化为低电平
    gpio_init(MOTOR_L1_IN1_PIN, GPO, 0, GPO_PUSH_PULL); // L1_IN1
    gpio_init(MOTOR_L1_IN2_PIN, GPO, 0, GPO_PUSH_PULL); // L1_IN2

    gpio_init(MOTOR_L2_IN1_PIN, GPO, 0, GPO_PUSH_PULL); // L2_IN1
    gpio_init(MOTOR_L2_IN2_PIN, GPO, 0, GPO_PUSH_PULL); // L2_IN2

    gpio_init(MOTOR_R1_IN1_PIN, GPO, 0, GPO_PUSH_PULL); // R1_IN1
    gpio_init(MOTOR_R1_IN2_PIN, GPO, 0, GPO_PUSH_PULL); // R1_IN2

    gpio_init(MOTOR_R2_IN1_PIN, GPO, 0, GPO_PUSH_PULL); // R2_IN1
    gpio_init(MOTOR_R2_IN2_PIN, GPO, 0, GPO_PUSH_PULL); // R2_IN2
}

// 左电机正转
void Motor_Left_Forward(void)
{
    gpio_set_level(MOTOR_L1_IN1_PIN, 1);
    gpio_set_level(MOTOR_L1_IN2_PIN, 0);

    gpio_set_level(MOTOR_L2_IN1_PIN, 1);
    gpio_set_level(MOTOR_L2_IN2_PIN, 0);
}

// 左电机反转
void Motor_Left_Reverse(void)
{
    gpio_set_level(MOTOR_L1_IN1_PIN, 0);
    gpio_set_level(MOTOR_L1_IN2_PIN, 1);

    gpio_set_level(MOTOR_L2_IN1_PIN, 0);
    gpio_set_level(MOTOR_L2_IN2_PIN, 1);
}

// 右电机正转
void Motor_Right_Forward(void)
{
    gpio_set_level(MOTOR_R1_IN1_PIN, 1);
    gpio_set_level(MOTOR_R1_IN2_PIN, 0);

    gpio_set_level(MOTOR_R2_IN1_PIN, 1);
    gpio_set_level(MOTOR_R2_IN2_PIN, 0);
}

// 右电机反转
void Motor_Right_Reverse(void)
{
    gpio_set_level(MOTOR_R1_IN1_PIN, 0);
    gpio_set_level(MOTOR_R1_IN2_PIN, 1);

    gpio_set_level(MOTOR_R2_IN1_PIN, 0);
    gpio_set_level(MOTOR_R2_IN2_PIN, 1);
}

// 左电机停止
void Motor_Left_Stop(void)
{
    gpio_set_level(MOTOR_L1_IN1_PIN, 0);
    gpio_set_level(MOTOR_L1_IN2_PIN, 0);

    gpio_set_level(MOTOR_L2_IN1_PIN, 0);
    gpio_set_level(MOTOR_L2_IN2_PIN, 0);
}

// 右电机停止
void Motor_Right_Stop(void)
{
    gpio_set_level(MOTOR_R1_IN1_PIN, 0);
    gpio_set_level(MOTOR_R1_IN2_PIN, 0);

    gpio_set_level(MOTOR_R2_IN1_PIN, 0);
    gpio_set_level(MOTOR_R2_IN2_PIN, 0);
}

// Car前进时 电机状态：左电机反转，右电机正转

void Motor_Forward(void)

{
    Motor_Left_Reverse();

    Motor_Right_Forward();
}

// Car后退时 电机状态：左电机正转，右电机反转
void Motor_Backward(void)
{
    Motor_Left_Forward();

    Motor_Right_Reverse();
}
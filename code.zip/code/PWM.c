#include "PWM.h"

/*
占空比在 PWM_DUTY_MAX（zf_driver_pwm.c） 设置最大值范围，现已定为10000，占空比：0~10000 由16位寄存器计数设置占空比
*/

void MyPWM_Init(void)
{
    pwm_init(PWM_CH1, 17000, 0);                                                // 初始化 PWM 通道 频率 17KHz 初始占空比 0%
    pwm_init(PWM_CH2, 17000, 0);                                                // 初始化 PWM 通道 频率 17KHz 初始占空比 0%
    pwm_init(PWM_CH3, 17000, 0);                                                // 初始化 PWM 通道 频率 17KHz 初始占空比 0%
    pwm_init(PWM_CH4, 17000, 0);                                                // 初始化 PWM 通道 频率 17KHz 初始占空比 0
}

void PWM_CH1_Set_Duty(pwm_channel_enum pin, const uint32 duty)
{
    pwm_set_duty(pin, duty);
}

void PWM_CH2_Set_Duty(pwm_channel_enum pin, const uint32 duty)
{
    pwm_set_duty(pin, duty);
}

void PWM_CH3_Set_Duty(pwm_channel_enum pin, const uint32 duty)
{
    pwm_set_duty(pin, duty);
}

void PWM_CH4_Set_Duty(pwm_channel_enum pin, const uint32 duty)
{
    pwm_set_duty(pin, duty);
}
